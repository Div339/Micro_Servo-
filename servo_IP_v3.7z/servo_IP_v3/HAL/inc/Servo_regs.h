#ifndef SERVO_REGS_H_INCLUDED
#define SERVO_REGS_H_INCLUDED

#include <io.h>
#include <system.h>

//The positions of the servo have been hardcoded in the hardvare as constants. 
//Position can only be changed in the SW from 0 to 90 to 180 degress. Changes the VHDL to variable or
//change the constant for other servo position. 

// +90 degress
#define MIN_MODE() IOWR_32DIRECT(SERVO_V2_0_BASE,0,0x20000000);

// 0 degress
#define MIDDLE_MODE() IOWR_32DIRECT(SERVO_V2_0_BASE,0,0x20000000);

// -90 degress
#define MAX_MODE() IOWR_32DIRECT(SERVO_V2_0_BASE,0,0x20000000);


#endif
